# Saber Auth

Single sign-on and per-app scoped access control for the Saber tools suite (SignalPulse, SentimentPulse, TripTracker, GenrePulse, GTM, and the suite launcher).

**Status:** Phase 1 build — service and admin UI are code-complete but not yet deployed. No Saber app has been cutover yet.

## What it does

- **Invite-only user accounts.** No self-signup. An admin invites you by email; you click the link, set a password, you're in.
- **One login for the whole suite.** A single `saber_session` cookie is trusted by every app on the same host. Log in once at `/auth/login.html`, browse SignalPulse/SentimentPulse/etc. without re-authing.
- **Per-app scopes.** Each user has an explicit list of app scopes they can access (e.g. `["signalpulse", "triptracker"]`). Each app enforces its own scope on every request.
- **Real revocation.**
  - _Revoke one user:_ their status flips to `revoked` and every existing session dies immediately.
  - _Revoke one session:_ single-session logout (e.g. suspicious IP), other sessions unaffected.
  - _Nuclear log-everyone-out:_ rotate `JWT_SECRET` env var and restart the service.
- **Password reset via email** (Resend, reusing the existing SentimentPulse key).
- **Audit log** of every admin action (invite, revoke, scope change).

## Architecture

- Node 20 + Express + `better-sqlite3` + `bcryptjs` + `jsonwebtoken`.
- Runs on port `5100` (configurable).
- Nginx routes `/auth/*` to it. All other paths (`/signal/`, `/sentiment/`, `/`, etc.) continue to hit their existing services.
- SQLite database at `data/saber-auth.db` (WAL mode).
- Each app integrates via a ~40-line middleware — see `integrations/node-express/`.

## First-run setup

```bash
# 1. Clone to the droplet
sudo mkdir -p /opt/saber-auth && sudo chown -R $USER /opt/saber-auth
git clone https://github.com/sallisonhome/saber-auth.git /opt/saber-auth

# 2. Configure
cd /opt/saber-auth
cp .env.example .env
# Edit .env:
#   - Generate JWT_SECRET:  node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
#   - Set BASE_URL to how the browser reaches this service (e.g. http://104.236.239.46)
#   - Set BOOTSTRAP_ADMIN_EMAIL to yourself
#   - Paste RESEND_API_KEY (reuse the SentimentPulse key)

# 3. Deploy
sudo deploy/deploy.sh

# 4. Add nginx snippet
sudo cp deploy/nginx-snippet.conf /etc/nginx/snippets/saber-auth.conf
# Add `include snippets/saber-auth.conf;` inside the sentimentpulse.conf server block
sudo nginx -t && sudo systemctl reload nginx

# 5. Check the systemd journal for the bootstrap admin invite URL:
sudo journalctl -u saber-auth -n 40 --no-pager | grep -A2 'Accept your invitation'
```

Open the printed URL, set your admin password, then invite everyone else at `/auth/admin.html`.

## Nuclear "log everyone out" procedure

```bash
# 1. Generate a new secret
NEW=$(node -e "console.log(require('crypto').randomBytes(48).toString('hex'))")

# 2. Update .env on droplet
sudo sed -i "s|^JWT_SECRET=.*|JWT_SECRET=$NEW|" /opt/saber-auth/.env

# 3. Update the same secret in every app that uses local JWT verification
#    (see integrations/node-express/), then restart them.

# 4. Restart saber-auth
sudo systemctl restart saber-auth
```

Every existing token immediately fails signature check across the whole suite. Users re-authenticate on their next request.

## Integrating a new Saber app

See [`integrations/node-express/`](./integrations/node-express/) for the drop-in middleware. Two-line integration:

```js
const { saberAuth } = require('./saber-auth-middleware');
const auth = saberAuth({ scope: 'my-app-name' });
app.use('/api', auth.requireScope);
```

Set `SABER_AUTH_JWT_SECRET` in the app's environment to the same value as `saber-auth`'s `JWT_SECRET`.

## Roadmap

- **Phase 2:** cut SignalPulse over first (feature-flagged, one-week fallback to old password gate).
- **Phase 3:** cut suite launcher + SentimentPulse over.
- **Phase 4:** cut TripTracker + GenrePulse + GTM over.
- **Phase 5:** retire the legacy `SABER` shared password everywhere.
- **Future:** optional remote-verify endpoint so integrated apps don't need the JWT secret and can honor per-session/per-user revocation without sharing the SQLite DB.

## Security notes

- Passwords hashed with bcrypt (12 rounds), minimum 10 chars.
- Reset tokens: 32 random bytes, SHA-256-hashed at rest, 1-hour expiry, single-use, 3-per-hour rate limit.
- Invite tokens: same shape, 7-day expiry, single-use.
- Session cookie: `HttpOnly; SameSite=Lax; Secure` (in production).
- No email enumeration on login or forgot-password paths — always identical generic response on miss.
