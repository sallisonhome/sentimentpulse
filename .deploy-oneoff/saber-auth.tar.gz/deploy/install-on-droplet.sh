#!/usr/bin/env bash
# Runs on the droplet. Assumes:
#   - /tmp/saber-auth.tar.gz has been scp'd here
#   - /tmp/saber-auth.env has been scp'd here (or /opt/saber-auth/.env already exists)
set -euo pipefail

echo "==> Ensuring /opt/saber-auth exists"
mkdir -p /opt/saber-auth

echo "==> Extracting tarball"
TMP=$(mktemp -d)
tar -xzf /tmp/saber-auth.tar.gz -C "$TMP"
# Preserve data/ and .env across redeploys
rsync -a --delete --exclude='data/' --exclude='.env' --exclude='node_modules/' "$TMP/" /opt/saber-auth/
rm -rf "$TMP" /tmp/saber-auth.tar.gz

if [ -f /tmp/saber-auth.env ]; then
  echo "==> Installing .env"
  mv /tmp/saber-auth.env /opt/saber-auth/.env
  chmod 600 /opt/saber-auth/.env
fi

echo "==> Node version"
node -v

echo "==> Installing npm deps (production)"
cd /opt/saber-auth
npm ci --omit=dev 2>&1 | tail -6

echo "==> Installing systemd unit"
install -m 0644 deploy/saber-auth.service /etc/systemd/system/saber-auth.service
systemctl daemon-reload
systemctl enable saber-auth 2>&1 | tail -3

echo "==> Restarting saber-auth"
systemctl restart saber-auth
sleep 3

echo "==> Loopback health check"
curl -sf http://127.0.0.1:5100/health && echo ""

echo "==> Installing nginx snippet (idempotent)"
python3 /opt/saber-auth/deploy/install-nginx-snippet.py
echo "==> nginx -t"
nginx -t
systemctl reload nginx

echo "==> Public health check via nginx"
curl -sf -o /dev/null -w "auth login page: HTTP %{http_code}\n" http://127.0.0.1/auth/login.html

echo ""
echo "======================================================================"
echo "==> Bootstrap admin invite URL (from journal, last 3 minutes):"
echo "======================================================================"
journalctl -u saber-auth --since '3 min ago' --no-pager | grep -B1 -A2 'accept-invite' || echo "(no invite URL found in journal — admin may already exist)"
echo "======================================================================"
echo "==> Service status:"
systemctl status saber-auth --no-pager -l | head -8
echo "==> Done."
