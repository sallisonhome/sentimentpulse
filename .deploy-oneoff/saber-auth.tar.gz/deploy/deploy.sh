#!/usr/bin/env bash
# One-shot deploy helper. Run manually the first time; after that use a GitHub Actions
# workflow like the other Saber repos.
#
# Assumes:
#   * Node 20+ installed
#   * nginx installed and serving the sentimentpulse.conf server block
#   * You've already scp'd the repo to /opt/saber-auth/
#   * You've filled in /opt/saber-auth/.env from .env.example
set -euo pipefail

cd /opt/saber-auth

echo ">> Installing dependencies (production only)"
npm ci --omit=dev

echo ">> Installing systemd unit"
install -m 0644 deploy/saber-auth.service /etc/systemd/system/saber-auth.service
systemctl daemon-reload
systemctl enable saber-auth

echo ">> Starting service"
systemctl restart saber-auth
sleep 2

echo ">> Health check"
curl -sf http://127.0.0.1:5100/health || (journalctl -u saber-auth -n 40 --no-pager; exit 1)

echo ">> Done. Add deploy/nginx-snippet.conf to your nginx server block, then:"
echo "     nginx -t && systemctl reload nginx"
