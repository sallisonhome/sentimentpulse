#!/usr/bin/env python3
"""Idempotently insert the saber-auth /auth/ location block into the shared
   sentimentpulse.conf server block on the droplet."""
import re
import sys

# Actual filename on this droplet is 'sentimentpulse' (no .conf extension). Try both
# so this script is portable across nginx layouts.
import os
CONF = None
for candidate in ['/etc/nginx/sites-enabled/sentimentpulse',
                  '/etc/nginx/sites-enabled/sentimentpulse.conf']:
    if os.path.exists(candidate):
        CONF = candidate
        break
if CONF is None:
    import sys
    print("ERROR: neither sentimentpulse nor sentimentpulse.conf found in /etc/nginx/sites-enabled/", file=sys.stderr)
    sys.exit(1)
MARKER = 'location /auth/'
SNIPPET = """
    # saber-auth (Saber Suite SSO)
    location /auth/ {
        proxy_pass http://127.0.0.1:5100/auth/;
        proxy_http_version 1.1;
        proxy_set_header Host              $host;
        proxy_set_header X-Real-IP         $remote_addr;
        proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 30s;
    }
"""

with open(CONF) as f:
    src = f.read()

if MARKER in src:
    print("/auth/ block already present, skipping")
    sys.exit(0)

new = re.sub(r'(server_name[^;]+;\s*\n)', r'\1' + SNIPPET + '\n', src, count=1)
if new == src:
    print("ERROR: could not find server_name line to anchor after", file=sys.stderr)
    sys.exit(1)

with open(CONF, 'w') as f:
    f.write(new)
print("Inserted /auth/ block into", CONF)
