/**
 * Saber Auth — SQLite schema and migrations.
 *
 * Tables:
 *   users             — one row per person invited to the suite
 *   invites           — pending invitations (hashed tokens, single-use, 7-day expiry)
 *   password_resets   — pending password reset tokens (hashed, single-use, 1-hour expiry)
 *   sessions          — issued JWTs (jti + revoked_at). Lets us revoke individual sessions
 *                       without rotating the global JWT secret. Global rotation still works
 *                       for the nuclear "log everyone out right now" case.
 *   audit_log         — durable record of admin actions (invite, revoke, scope change)
 */
'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

let dbInstance = null;

function getDb() {
  if (dbInstance) return dbInstance;
  const dbPath = process.env.DB_PATH || path.join(__dirname, '..', '..', 'data', 'saber-auth.db');
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  dbInstance = new Database(dbPath);
  dbInstance.pragma('journal_mode = WAL');
  dbInstance.pragma('foreign_keys = ON');
  runMigrations(dbInstance);
  return dbInstance;
}

function runMigrations(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id              TEXT PRIMARY KEY,
      email           TEXT UNIQUE NOT NULL,
      display_name    TEXT,
      password_hash   TEXT,               -- null until invite is accepted
      status          TEXT NOT NULL DEFAULT 'invited'
                        CHECK (status IN ('invited','active','revoked')),
      scopes          TEXT NOT NULL DEFAULT '[]',   -- JSON array of app scope strings
      token_version   INTEGER NOT NULL DEFAULT 1,   -- bump to revoke ALL of this user's sessions
      is_admin        INTEGER NOT NULL DEFAULT 0,
      created_at      TEXT NOT NULL DEFAULT (datetime('now')),
      last_login_at   TEXT,
      revoked_at      TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_users_email ON users(LOWER(email));
    CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);

    CREATE TABLE IF NOT EXISTS invites (
      id            TEXT PRIMARY KEY,
      user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash    TEXT NOT NULL,        -- sha256(rawToken)
      created_by    TEXT REFERENCES users(id),
      expires_at    TEXT NOT NULL,
      accepted_at   TEXT,
      revoked_at    TEXT,
      created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_invites_token ON invites(token_hash);
    CREATE INDEX IF NOT EXISTS idx_invites_user ON invites(user_id);

    CREATE TABLE IF NOT EXISTS password_resets (
      id           TEXT PRIMARY KEY,
      user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash   TEXT NOT NULL,
      expires_at   TEXT NOT NULL,
      used_at      TEXT,
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_pw_resets_token ON password_resets(token_hash);
    CREATE INDEX IF NOT EXISTS idx_pw_resets_user ON password_resets(user_id);

    CREATE TABLE IF NOT EXISTS sessions (
      jti           TEXT PRIMARY KEY,     -- JWT id claim
      user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      issued_at     TEXT NOT NULL DEFAULT (datetime('now')),
      expires_at    TEXT NOT NULL,
      last_seen_at  TEXT,
      user_agent    TEXT,
      ip            TEXT,
      revoked_at    TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
    CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);

    CREATE TABLE IF NOT EXISTS audit_log (
      id           TEXT PRIMARY KEY,
      actor_id     TEXT REFERENCES users(id),
      action       TEXT NOT NULL,
      target_id    TEXT,
      details      TEXT,                  -- JSON
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_log(actor_id);
    CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log(action);
    CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log(created_at);
  `);
}

module.exports = { getDb };
