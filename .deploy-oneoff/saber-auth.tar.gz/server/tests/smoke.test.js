/**
 * End-to-end smoke test — spins up the real server against a temp SQLite DB,
 * walks the whole invite → accept → login → protected-route → revoke flow.
 *
 * Run: node --test server/tests/smoke.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

// Isolate DB per run
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'saber-auth-test-'));
process.env.DB_PATH = path.join(tmpDir, 'saber-auth.db');
process.env.PORT = '0';
process.env.JWT_SECRET = 'test-secret-'.padEnd(64, 'x');
process.env.BASE_URL = 'http://localhost';
process.env.BOOTSTRAP_ADMIN_EMAIL = 'admin@example.com';
process.env.BOOTSTRAP_ADMIN_PASSWORD = 'admin-password-abcdef';
process.env.NODE_ENV = 'test';
// Suppress console output during tests
const origLog = console.log; const origWarn = console.warn;
console.log = () => {}; console.warn = () => {};

// Build the app manually (mirrors server/index.js) so we can control the port.
const express = require('express');
const cookieParser = require('cookie-parser');
const { getDb } = require('../db/schema');
const { bootstrapAdmin } = require('../bootstrap');
const authRoutes = require('../routes/auth').router;
const adminRoutes = require('../routes/admin');

const app = express();
app.use(express.json());
app.use(cookieParser());
app.use('/auth/api', authRoutes);
app.use('/auth/api/admin', adminRoutes);

let server, baseUrl;

test.before(async () => {
  getDb();
  await bootstrapAdmin();
  server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

test.after(() => {
  console.log = origLog; console.warn = origWarn;
  server.close();
});

async function req(method, path, { body, cookie, headers = {} } = {}) {
  const res = await fetch(`${baseUrl}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(cookie ? { Cookie: cookie } : {}),
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch {}
  return { status: res.status, body: json, raw: text, setCookie: res.headers.get('set-cookie') };
}

function extractCookie(setCookie) {
  if (!setCookie) return null;
  const m = setCookie.split(';')[0];
  return m || null;
}

test('bootstrap admin can log in', async () => {
  const r = await req('POST', '/auth/api/login', {
    body: { email: 'admin@example.com', password: 'admin-password-abcdef' },
  });
  assert.equal(r.status, 200);
  assert.ok(r.body.token);
  assert.equal(r.body.user.email, 'admin@example.com');
  assert.equal(r.body.user.isAdmin, true);
});

test('bad password is rejected with generic error', async () => {
  const r = await req('POST', '/auth/api/login', {
    body: { email: 'admin@example.com', password: 'wrong' },
  });
  assert.equal(r.status, 401);
  assert.match(r.body.error, /Invalid email or password/);
});

test('unknown email returns same generic error (no enumeration)', async () => {
  const r = await req('POST', '/auth/api/login', {
    body: { email: 'nope@example.com', password: 'anything' },
  });
  assert.equal(r.status, 401);
  assert.match(r.body.error, /Invalid email or password/);
});

let adminCookie;

test('admin login yields session cookie', async () => {
  const r = await req('POST', '/auth/api/login', {
    body: { email: 'admin@example.com', password: 'admin-password-abcdef' },
  });
  adminCookie = extractCookie(r.setCookie);
  assert.ok(adminCookie && adminCookie.startsWith('saber_session='));
});

test('/me returns admin', async () => {
  const r = await req('GET', '/auth/api/me', { cookie: adminCookie });
  assert.equal(r.status, 200);
  assert.equal(r.body.user.email, 'admin@example.com');
  assert.equal(r.body.user.isAdmin, true);
});

test('/me without cookie is 401', async () => {
  const r = await req('GET', '/auth/api/me');
  assert.equal(r.status, 401);
});

let inviteToken; let inviteeUserId;

test('admin can invite a user with specific scopes', async () => {
  const r = await req('POST', '/auth/api/admin/invite', {
    cookie: adminCookie,
    body: { email: 'alice@example.com', scopes: ['signalpulse', 'triptracker'] },
  });
  assert.equal(r.status, 201);
  assert.equal(r.body.email, 'alice@example.com');
  assert.deepEqual(r.body.scopes.sort(), ['signalpulse', 'triptracker']);
  assert.match(r.body.acceptUrl, /accept-invite\.html\?token=[a-f0-9]{64}/);
  // Grab the token from the acceptUrl for the next test.
  inviteToken = new URL(r.body.acceptUrl).searchParams.get('token');
  inviteeUserId = r.body.userId;
});

test('invite preview endpoint works', async () => {
  const r = await req('GET', `/auth/api/invite/preview?token=${inviteToken}`);
  assert.equal(r.status, 200);
  assert.equal(r.body.email, 'alice@example.com');
  assert.deepEqual(r.body.scopes.sort(), ['signalpulse', 'triptracker']);
});

let aliceCookie;

test('invitee accepts and receives a session', async () => {
  const r = await req('POST', '/auth/api/accept-invite', {
    body: { token: inviteToken, password: 'alice-password-123', displayName: 'Alice' },
  });
  assert.equal(r.status, 200);
  assert.equal(r.body.user.email, 'alice@example.com');
  assert.equal(r.body.user.isAdmin, false);
  assert.deepEqual(r.body.user.scopes.sort(), ['signalpulse', 'triptracker']);
  aliceCookie = extractCookie(r.setCookie);
});

test('invite token cannot be reused', async () => {
  const r = await req('POST', '/auth/api/accept-invite', {
    body: { token: inviteToken, password: 'anything-goes-1234' },
  });
  assert.equal(r.status, 400);
});

test('non-admin cannot hit admin routes', async () => {
  const r = await req('GET', '/auth/api/admin/users', { cookie: aliceCookie });
  assert.equal(r.status, 403);
});

test('alice can log in with her new password', async () => {
  const r = await req('POST', '/auth/api/login', {
    body: { email: 'alice@example.com', password: 'alice-password-123' },
  });
  assert.equal(r.status, 200);
  aliceCookie = extractCookie(r.setCookie);
});

test('admin can update alice\'s scopes', async () => {
  const r = await req('PATCH', `/auth/api/admin/users/${inviteeUserId}/scopes`, {
    cookie: adminCookie,
    body: { scopes: ['signalpulse'], isAdmin: false },
  });
  assert.equal(r.status, 200);
  // Alice's old cookie should now be invalid (token_version bumped).
  const me = await req('GET', '/auth/api/me', { cookie: aliceCookie });
  assert.equal(me.status, 401);
});

test('unknown scope is rejected', async () => {
  const r = await req('PATCH', `/auth/api/admin/users/${inviteeUserId}/scopes`, {
    cookie: adminCookie,
    body: { scopes: ['nonsense'], isAdmin: false },
  });
  assert.equal(r.status, 400);
  assert.match(r.body.error, /Unknown scope/);
});

test('alice logs back in and gets fresh scopes', async () => {
  const r = await req('POST', '/auth/api/login', {
    body: { email: 'alice@example.com', password: 'alice-password-123' },
  });
  assert.equal(r.status, 200);
  aliceCookie = extractCookie(r.setCookie);
  assert.deepEqual(r.body.user.scopes, ['signalpulse']);
});

test('revoking alice kills her session immediately', async () => {
  const r = await req('POST', `/auth/api/admin/users/${inviteeUserId}/revoke`, {
    cookie: adminCookie,
  });
  assert.equal(r.status, 200);
  const me = await req('GET', '/auth/api/me', { cookie: aliceCookie });
  assert.equal(me.status, 401);
});

test('revoked user cannot log back in', async () => {
  const r = await req('POST', '/auth/api/login', {
    body: { email: 'alice@example.com', password: 'alice-password-123' },
  });
  assert.equal(r.status, 401);
});

test('reinstate restores login', async () => {
  await req('POST', `/auth/api/admin/users/${inviteeUserId}/reinstate`, { cookie: adminCookie });
  const r = await req('POST', '/auth/api/login', {
    body: { email: 'alice@example.com', password: 'alice-password-123' },
  });
  assert.equal(r.status, 200);
});

test('cannot revoke self', async () => {
  const me = await req('GET', '/auth/api/me', { cookie: adminCookie });
  const r = await req('POST', `/auth/api/admin/users/${me.body.user.id}/revoke`, { cookie: adminCookie });
  assert.equal(r.status, 400);
});

test('duplicate invite for active user is rejected', async () => {
  const r = await req('POST', '/auth/api/admin/invite', {
    cookie: adminCookie,
    body: { email: 'alice@example.com', scopes: ['signalpulse'] },
  });
  assert.equal(r.status, 409);
});

test('forgot-password never enumerates email', async () => {
  const r1 = await req('POST', '/auth/api/forgot-password', { body: { email: 'alice@example.com' } });
  const r2 = await req('POST', '/auth/api/forgot-password', { body: { email: 'nobody@example.com' } });
  assert.equal(r1.status, 200);
  assert.equal(r2.status, 200);
  assert.equal(r1.body.message, r2.body.message);
});

test('audit log records invite + revoke', async () => {
  const r = await req('GET', '/auth/api/admin/audit?limit=10', { cookie: adminCookie });
  assert.equal(r.status, 200);
  const actions = r.body.entries.map(e => e.action);
  assert.ok(actions.includes('invite'));
  assert.ok(actions.includes('revoke_user'));
});

test('logout revokes the session', async () => {
  const login = await req('POST', '/auth/api/login', {
    body: { email: 'admin@example.com', password: 'admin-password-abcdef' },
  });
  const c = extractCookie(login.setCookie);
  await req('POST', '/auth/api/logout', { cookie: c });
  const me = await req('GET', '/auth/api/me', { cookie: c });
  assert.equal(me.status, 401);
});
