/**
 * Email delivery via Resend.
 *
 * Reads RESEND_API_KEY + RESEND_FROM from the environment. If the key is missing
 * or clearly a placeholder, we log the message locally and return { skipped: true }
 * rather than crashing — makes dev/testing frictionless.
 */
'use strict';

async function sendEmail({ to, subject, html, text }) {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.RESEND_FROM || 'Saber Suite <noreply@mail.howmanyareplaying.com>';

  if (!apiKey || apiKey === 're_your_key_here' || !apiKey.startsWith('re_')) {
    // eslint-disable-next-line no-console
    console.warn('[saber-auth email] RESEND_API_KEY missing/placeholder — logging instead of sending', {
      to, subject,
    });
    // eslint-disable-next-line no-console
    console.log('[saber-auth email:body]\n' + (text || html));
    return { skipped: true };
  }

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from, to, subject, html, text }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => '');
    const err = new Error(`Resend ${res.status}: ${body}`);
    err.status = res.status;
    err.body = body;
    throw err;
  }
  return await res.json();
}

module.exports = { sendEmail };
