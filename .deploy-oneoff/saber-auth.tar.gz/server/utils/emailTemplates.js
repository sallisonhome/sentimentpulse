/**
 * HTML/text templates for Saber Auth emails. Kept boring and inline-styled so they
 * render in every client, including old Outlook/Yahoo, and won't break if CSS changes.
 */
'use strict';

function inviteEmail({ acceptUrl, inviterEmail, scopes }) {
  const scopeList = scopes.filter(s => s !== 'admin').join(', ') || 'the Saber Suite';
  const html = `
    <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:520px;margin:0 auto;padding:24px;background:#ffffff;color:#0f172a;">
      <h2 style="color:#1a3a5c;margin:0 0 12px;font-size:22px;">You've been invited to the Saber Suite</h2>
      <p style="font-size:15px;line-height:1.55;margin:0 0 12px;">
        ${escape(inviterEmail || 'A Saber admin')} has invited you to access ${escape(scopeList)}.
      </p>
      <p style="font-size:15px;line-height:1.55;margin:0 0 20px;">
        Click the button below to set your password and finish creating your account.
      </p>
      <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin:20px 0;">
        <tr><td style="background:#1a3a5c;border-radius:8px;">
          <a href="${escape(acceptUrl)}" style="display:inline-block;color:#ffffff;padding:14px 28px;border-radius:8px;text-decoration:none;font-weight:700;font-size:16px;">
            Accept Invitation
          </a>
        </td></tr>
      </table>
      <p style="color:#64748b;font-size:13px;line-height:1.5;margin:20px 0 0;">
        This invite expires in 7 days. If you weren't expecting this email, you can safely ignore it.
      </p>
    </div>
  `;
  const text = `You've been invited to the Saber Suite.
${inviterEmail || 'A Saber admin'} has invited you to access ${scopeList}.

Set your password: ${acceptUrl}

This invite expires in 7 days. If you weren't expecting this, ignore this email.`;
  return { html, text };
}

function resetEmail({ resetUrl }) {
  const html = `
    <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:520px;margin:0 auto;padding:24px;background:#ffffff;color:#0f172a;">
      <h2 style="color:#1a3a5c;margin:0 0 12px;font-size:22px;">Reset your Saber Suite password</h2>
      <p style="font-size:15px;line-height:1.55;margin:0 0 20px;">
        Click the button below to choose a new password. This link expires in 1 hour.
      </p>
      <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin:20px 0;">
        <tr><td style="background:#1a3a5c;border-radius:8px;">
          <a href="${escape(resetUrl)}" style="display:inline-block;color:#ffffff;padding:14px 28px;border-radius:8px;text-decoration:none;font-weight:700;font-size:16px;">
            Reset Password
          </a>
        </td></tr>
      </table>
      <p style="color:#64748b;font-size:13px;line-height:1.5;margin:20px 0 0;">
        If you didn't request this, you can safely ignore this email.
      </p>
    </div>
  `;
  const text = `Reset your Saber Suite password.

Reset link (expires in 1 hour): ${resetUrl}

If you didn't request this, ignore this email.`;
  return { html, text };
}

function escape(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

module.exports = { inviteEmail, resetEmail };
