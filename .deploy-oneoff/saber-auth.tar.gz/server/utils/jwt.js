/**
 * JWT signing + verification + session tracking.
 *
 * Every issued token has:
 *   - jti (UUID)              — recorded in `sessions` so it can be individually revoked
 *   - sub (user id)
 *   - tv  (token_version)     — checked against users.token_version; mismatch = revoked
 *   - scopes                  — array of app scope strings
 *   - is_admin                — boolean flag
 *
 * Global "log everyone out" is achieved by rotating JWT_SECRET (all existing tokens
 * fail signature check). Individual-user revocation bumps users.token_version.
 * Individual-session revocation sets sessions.revoked_at.
 */
'use strict';

const jwt = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const { getDb } = require('../db/schema');
const { JWT_EXPIRY_DAYS } = require('../constants');

function jwtSecret() {
  const s = process.env.JWT_SECRET;
  if (!s || s === 'change-me-to-a-64-plus-hex-secret' || s.length < 32) {
    throw new Error('JWT_SECRET is not set (or too short). Refusing to sign or verify tokens.');
  }
  return s;
}

function issueSession(user, { userAgent, ip } = {}) {
  const db = getDb();
  const jti = uuid();
  const expiresInSec = JWT_EXPIRY_DAYS * 24 * 60 * 60;
  const expiresAt = new Date(Date.now() + expiresInSec * 1000).toISOString();
  const scopes = safeParseScopes(user.scopes);

  const token = jwt.sign(
    {
      sub: user.id,
      email: user.email,
      tv: user.token_version,
      scopes,
      is_admin: !!user.is_admin,
    },
    jwtSecret(),
    { jwtid: jti, expiresIn: expiresInSec }
  );

  db.prepare(`
    INSERT INTO sessions (jti, user_id, expires_at, last_seen_at, user_agent, ip)
    VALUES (?, ?, ?, datetime('now'), ?, ?)
  `).run(jti, user.id, expiresAt, userAgent || null, ip || null);

  return { token, jti, expiresAt };
}

/**
 * Verify a token AND check it hasn't been revoked at the user or session level.
 * Returns the decoded payload, or null on any failure.
 */
function verifySession(token) {
  if (!token) return null;
  let decoded;
  try {
    decoded = jwt.verify(token, jwtSecret());
  } catch {
    return null;
  }
  const db = getDb();

  // Session revocation check
  const session = db.prepare('SELECT jti, revoked_at FROM sessions WHERE jti = ?').get(decoded.jti);
  if (!session || session.revoked_at) return null;

  // User revocation check + token_version freshness check
  const user = db.prepare(
    'SELECT id, email, status, scopes, token_version, is_admin FROM users WHERE id = ?'
  ).get(decoded.sub);
  if (!user || user.status !== 'active') return null;
  if (user.token_version !== decoded.tv) return null;

  // Best-effort last-seen update — swallow errors so verification never fails on this.
  try {
    db.prepare("UPDATE sessions SET last_seen_at = datetime('now') WHERE jti = ?").run(decoded.jti);
  } catch { /* ignore */ }

  return {
    userId: user.id,
    email: user.email,
    scopes: safeParseScopes(user.scopes),
    isAdmin: !!user.is_admin,
    jti: decoded.jti,
  };
}

function revokeSession(jti) {
  const db = getDb();
  db.prepare("UPDATE sessions SET revoked_at = datetime('now') WHERE jti = ? AND revoked_at IS NULL").run(jti);
}

function safeParseScopes(v) {
  if (Array.isArray(v)) return v;
  if (typeof v !== 'string') return [];
  try { const p = JSON.parse(v); return Array.isArray(p) ? p : []; } catch { return []; }
}

module.exports = { issueSession, verifySession, revokeSession, safeParseScopes };
