/**
 * Auth middleware — used internally by saber-auth admin routes.
 *
 * Each Saber APP integrates via a lightweight snippet (see docs/INTEGRATION.md),
 * NOT by mounting this file directly, so we don't force the whole express stack
 * on every app.
 */
'use strict';

const { verifySession } = require('../utils/jwt');

const COOKIE_NAME = 'saber_session';

function extractToken(req) {
  const auth = req.headers.authorization;
  if (auth && auth.startsWith('Bearer ')) return auth.slice(7);
  if (req.cookies && req.cookies[COOKIE_NAME]) return req.cookies[COOKIE_NAME];
  return null;
}

function requireAuth(req, res, next) {
  const token = extractToken(req);
  const session = verifySession(token);
  if (!session) return res.status(401).json({ error: 'Authentication required.' });
  req.session = session;
  next();
}

function requireAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (!req.session.isAdmin) return res.status(403).json({ error: 'Admin scope required.' });
    next();
  });
}

function requireScope(scope) {
  return (req, res, next) => {
    requireAuth(req, res, () => {
      if (!req.session.scopes.includes(scope) && !req.session.isAdmin) {
        return res.status(403).json({ error: `Scope '${scope}' required.` });
      }
      next();
    });
  };
}

module.exports = { requireAuth, requireAdmin, requireScope, extractToken, COOKIE_NAME };
