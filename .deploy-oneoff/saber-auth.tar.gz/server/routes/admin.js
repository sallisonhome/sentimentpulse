/**
 * Admin routes — invite/list/revoke/scope-management. All require `admin` scope.
 *
 * "Revoke user"     — bumps token_version + marks status='revoked' + revokes all sessions.
 * "Rotate scopes"   — updates scopes and bumps token_version (their next request will
 *                     mint fresh scopes).
 * "Revoke session"  — targeted single-session logout (e.g. suspicious IP).
 *
 * The nuclear "log everyone out right now" action is deliberately NOT a route —
 * it's an operator action performed by rotating the JWT_SECRET env var and restarting
 * the service. Documented in README.md.
 */
'use strict';

const express = require('express');
const crypto = require('crypto');
const { v4: uuid } = require('uuid');

const { getDb } = require('../db/schema');
const { requireAdmin } = require('../middleware/auth');
const { sendEmail } = require('../utils/email');
const { inviteEmail } = require('../utils/emailTemplates');
const { safeParseScopes } = require('../utils/jwt');
const { safeUser } = require('./auth');
const { KNOWN_SCOPES, INVITE_EXPIRY_DAYS } = require('../constants');

const router = express.Router();
router.use(requireAdmin);

function audit(db, actorId, action, targetId, details) {
  db.prepare(`
    INSERT INTO audit_log (id, actor_id, action, target_id, details)
    VALUES (?, ?, ?, ?, ?)
  `).run(uuid(), actorId, action, targetId || null, details ? JSON.stringify(details) : null);
}

function validateScopes(scopes) {
  if (!Array.isArray(scopes)) return { ok: false, error: 'scopes must be an array' };
  const invalid = scopes.filter(s => !KNOWN_SCOPES.includes(s));
  if (invalid.length) return { ok: false, error: `Unknown scopes: ${invalid.join(', ')}` };
  return { ok: true, scopes: [...new Set(scopes)] };
}

// GET /admin/users — list all users
router.get('/users', (req, res) => {
  const db = getDb();
  const users = db.prepare(`
    SELECT id, email, display_name, status, scopes, is_admin, created_at, last_login_at, revoked_at
    FROM users ORDER BY created_at DESC
  `).all();
  res.json({
    users: users.map(u => ({
      id: u.id, email: u.email, displayName: u.display_name, status: u.status,
      scopes: safeParseScopes(u.scopes), isAdmin: !!u.is_admin,
      createdAt: u.created_at, lastLoginAt: u.last_login_at, revokedAt: u.revoked_at,
    })),
  });
});

// POST /admin/invite — invite a new user
router.post('/invite', async (req, res) => {
  const { email, scopes, displayName, isAdmin } = req.body || {};
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'Valid email required.' });
  }
  const check = validateScopes(scopes || []);
  if (!check.ok) return res.status(400).json({ error: check.error });

  const db = getDb();
  const existing = db.prepare('SELECT id, status FROM users WHERE LOWER(email) = LOWER(?)').get(email);
  if (existing && existing.status !== 'revoked') {
    return res.status(409).json({ error: 'That email is already invited or active.' });
  }

  const userId = existing?.id || uuid();
  const rawToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  const expiresAt = new Date(Date.now() + INVITE_EXPIRY_DAYS * 86400 * 1000).toISOString();

  const tx = db.transaction(() => {
    if (existing) {
      db.prepare(`
        UPDATE users SET status = 'invited', scopes = ?, is_admin = ?,
                         display_name = COALESCE(?, display_name),
                         revoked_at = NULL, token_version = token_version + 1
        WHERE id = ?
      `).run(JSON.stringify(check.scopes), isAdmin ? 1 : 0, displayName || null, userId);
    } else {
      db.prepare(`
        INSERT INTO users (id, email, display_name, status, scopes, is_admin)
        VALUES (?, ?, ?, 'invited', ?, ?)
      `).run(userId, email, displayName || null, JSON.stringify(check.scopes), isAdmin ? 1 : 0);
    }
    db.prepare(`
      INSERT INTO invites (id, user_id, token_hash, created_by, expires_at)
      VALUES (?, ?, ?, ?, ?)
    `).run(uuid(), userId, tokenHash, req.session.userId, expiresAt);
    audit(db, req.session.userId, 'invite', userId, { email, scopes: check.scopes, isAdmin: !!isAdmin });
  });
  tx();

  const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 5100}`;
  const acceptUrl = `${baseUrl}/auth/accept-invite.html?token=${rawToken}`;
  const { html, text } = inviteEmail({ acceptUrl, inviterEmail: req.session.email, scopes: check.scopes });

  let emailStatus = 'sent';
  try {
    const result = await sendEmail({ to: email, subject: 'You\'ve been invited to the Saber Suite', html, text });
    if (result && result.skipped) emailStatus = 'skipped_no_key';
  } catch (err) {
    emailStatus = `failed: ${err.message}`;
    console.error('[saber-auth invite] email failed', err.message);
  }

  res.status(201).json({
    userId,
    email,
    scopes: check.scopes,
    isAdmin: !!isAdmin,
    expiresAt,
    emailStatus,
    // Return acceptUrl so admin UI can copy-paste as fallback when email delivery is uncertain.
    acceptUrl,
  });
});

// POST /admin/users/:id/revoke — revoke a user (status=revoked, all sessions killed)
router.post('/users/:id/revoke', (req, res) => {
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  if (user.id === req.session.userId) return res.status(400).json({ error: 'Cannot revoke yourself.' });

  const tx = db.transaction(() => {
    db.prepare(`
      UPDATE users SET status = 'revoked', revoked_at = datetime('now'),
                       token_version = token_version + 1
      WHERE id = ?
    `).run(user.id);
    db.prepare("UPDATE sessions SET revoked_at = datetime('now') WHERE user_id = ? AND revoked_at IS NULL")
      .run(user.id);
    db.prepare("UPDATE invites SET revoked_at = datetime('now') WHERE user_id = ? AND accepted_at IS NULL AND revoked_at IS NULL")
      .run(user.id);
    audit(db, req.session.userId, 'revoke_user', user.id, { email: user.email });
  });
  tx();
  res.json({ ok: true });
});

// POST /admin/users/:id/reinstate — flip status back to active without a new invite
router.post('/users/:id/reinstate', (req, res) => {
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  if (!user.password_hash) return res.status(400).json({ error: 'User has never accepted an invite. Send a new invite instead.' });
  db.prepare("UPDATE users SET status = 'active', revoked_at = NULL WHERE id = ?").run(user.id);
  audit(db, req.session.userId, 'reinstate_user', user.id, { email: user.email });
  res.json({ ok: true });
});

// PATCH /admin/users/:id/scopes — update scopes/is_admin
router.patch('/users/:id/scopes', (req, res) => {
  const { scopes, isAdmin } = req.body || {};
  const check = validateScopes(scopes || []);
  if (!check.ok) return res.status(400).json({ error: check.error });

  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  db.prepare(`
    UPDATE users SET scopes = ?, is_admin = ?, token_version = token_version + 1
    WHERE id = ?
  `).run(JSON.stringify(check.scopes), isAdmin ? 1 : 0, user.id);
  audit(db, req.session.userId, 'update_scopes', user.id, { scopes: check.scopes, isAdmin: !!isAdmin });
  res.json({ ok: true });
});

// GET /admin/audit — recent audit-log entries
router.get('/audit', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit || '50', 10), 500);
  const db = getDb();
  const rows = db.prepare(`
    SELECT a.id, a.action, a.target_id, a.details, a.created_at,
           u.email AS actor_email
    FROM audit_log a LEFT JOIN users u ON u.id = a.actor_id
    ORDER BY a.created_at DESC LIMIT ?
  `).all(limit);
  res.json({
    entries: rows.map(r => ({
      id: r.id, action: r.action, targetId: r.target_id,
      details: r.details ? JSON.parse(r.details) : null,
      createdAt: r.created_at, actorEmail: r.actor_email,
    })),
  });
});

// GET /admin/scopes — canonical scope list (for admin UI dropdowns)
router.get('/scopes', (_req, res) => {
  res.json({ scopes: KNOWN_SCOPES });
});

module.exports = router;
