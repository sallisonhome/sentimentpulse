/**
 * User-facing auth routes: login, logout, me, forgot-password, reset-password,
 * accept-invite. Admin-only routes live in routes/admin.js.
 */
'use strict';

const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { v4: uuid } = require('uuid');

const { getDb } = require('../db/schema');
const { issueSession, revokeSession, safeParseScopes } = require('../utils/jwt');
const { requireAuth, COOKIE_NAME } = require('../middleware/auth');
const { sendEmail } = require('../utils/email');
const { resetEmail } = require('../utils/emailTemplates');
const {
  BCRYPT_ROUNDS, MIN_PASSWORD_LENGTH, PW_RESET_EXPIRY_HOURS, PW_RESET_RATE_LIMIT_PER_HOUR,
} = require('../constants');

const router = express.Router();

function setSessionCookie(res, token) {
  const isProd = process.env.NODE_ENV === 'production';
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    secure: isProd,
    sameSite: 'lax',
    domain: process.env.COOKIE_DOMAIN || undefined,
    path: '/',
    maxAge: 30 * 24 * 60 * 60 * 1000,
  });
}

function clearSessionCookie(res) {
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    sameSite: 'lax',
    domain: process.env.COOKIE_DOMAIN || undefined,
    path: '/',
  });
}

function safeUser(u) {
  return {
    id: u.id,
    email: u.email,
    displayName: u.display_name || u.email,
    scopes: safeParseScopes(u.scopes),
    isAdmin: !!u.is_admin,
    status: u.status,
    createdAt: u.created_at,
    lastLoginAt: u.last_login_at,
  };
}

// POST /login  — email + password
router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(?)').get(email);

  // Generic failure message on all bad-credential cases to avoid enumeration.
  const bad = () => res.status(401).json({ error: 'Invalid email or password.' });
  if (!user || !user.password_hash) return bad();
  if (user.status !== 'active') return bad();

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return bad();

  const { token } = issueSession(user, {
    userAgent: req.headers['user-agent'],
    ip: req.ip,
  });
  db.prepare("UPDATE users SET last_login_at = datetime('now') WHERE id = ?").run(user.id);

  setSessionCookie(res, token);
  res.json({ user: safeUser(user), token });
});

// POST /logout — revoke current session
router.post('/logout', requireAuth, (req, res) => {
  revokeSession(req.session.jti);
  clearSessionCookie(res);
  res.json({ ok: true });
});

// GET /me — current authenticated user
router.get('/me', requireAuth, (req, res) => {
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.userId);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json({ user: safeUser(user) });
});

// POST /accept-invite — set password, activate account, log in
router.post('/accept-invite', async (req, res) => {
  const { token, password, displayName } = req.body || {};
  if (!token || !password) return res.status(400).json({ error: 'Token and password are required.' });
  if (password.length < MIN_PASSWORD_LENGTH) {
    return res.status(400).json({ error: `Password must be at least ${MIN_PASSWORD_LENGTH} characters.` });
  }

  const db = getDb();
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const invite = db.prepare(`
    SELECT * FROM invites
    WHERE token_hash = ?
      AND accepted_at IS NULL
      AND revoked_at IS NULL
      AND expires_at > datetime('now')
  `).get(tokenHash);
  if (!invite) return res.status(400).json({ error: 'Invalid or expired invitation.' });

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(invite.user_id);
  if (!user || user.status === 'revoked') {
    return res.status(400).json({ error: 'This account is no longer valid.' });
  }

  const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);
  const tx = db.transaction(() => {
    db.prepare(`
      UPDATE users
      SET password_hash = ?, status = 'active', display_name = COALESCE(?, display_name)
      WHERE id = ?
    `).run(passwordHash, displayName || null, user.id);
    db.prepare("UPDATE invites SET accepted_at = datetime('now') WHERE id = ?").run(invite.id);
  });
  tx();

  const activated = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
  const { token: jwtToken } = issueSession(activated, {
    userAgent: req.headers['user-agent'],
    ip: req.ip,
  });
  setSessionCookie(res, jwtToken);
  res.json({ user: safeUser(activated), token: jwtToken });
});

// GET /invite/preview?token=… — resolve an invite token so the accept page can
// show who it's for without leaking existence to attackers (returns generic 404 on miss).
router.get('/invite/preview', (req, res) => {
  const token = String(req.query.token || '');
  if (!token) return res.status(400).json({ error: 'Token required.' });
  const db = getDb();
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const invite = db.prepare(`
    SELECT i.expires_at, u.email, u.scopes, u.status
    FROM invites i JOIN users u ON u.id = i.user_id
    WHERE i.token_hash = ?
      AND i.accepted_at IS NULL
      AND i.revoked_at IS NULL
      AND i.expires_at > datetime('now')
  `).get(tokenHash);
  if (!invite) return res.status(404).json({ error: 'Invalid or expired invitation.' });
  res.json({
    email: invite.email,
    scopes: safeParseScopes(invite.scopes),
    expiresAt: invite.expires_at,
  });
});

// POST /forgot-password
router.post('/forgot-password', async (req, res) => {
  const { email } = req.body || {};
  if (!email) return res.status(400).json({ error: 'Email required.' });

  const db = getDb();
  const user = db.prepare(`
    SELECT * FROM users WHERE LOWER(email) = LOWER(?) AND status = 'active'
  `).get(email);

  // Always respond identically to prevent enumeration.
  const genericOk = () => res.json({ message: 'If that email is registered, a reset link has been sent.' });

  if (!user) return genericOk();

  const recent = db.prepare(`
    SELECT COUNT(*) AS c FROM password_resets
    WHERE user_id = ? AND created_at > datetime('now', '-1 hour')
  `).get(user.id).c;
  if (recent >= PW_RESET_RATE_LIMIT_PER_HOUR) return genericOk();

  const rawToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  const expiresAt = new Date(Date.now() + PW_RESET_EXPIRY_HOURS * 3600 * 1000).toISOString();
  db.prepare(`
    INSERT INTO password_resets (id, user_id, token_hash, expires_at)
    VALUES (?, ?, ?, ?)
  `).run(uuid(), user.id, tokenHash, expiresAt);

  const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 5100}`;
  const resetUrl = `${baseUrl}/auth/reset-password.html?token=${rawToken}`;
  const { html, text } = resetEmail({ resetUrl });

  try {
    await sendEmail({ to: user.email, subject: 'Reset your Saber Suite password', html, text });
  } catch (err) {
    console.error('[saber-auth] password reset email failed', err.message);
    // Still return generic OK so we don't leak.
  }
  genericOk();
});

// POST /reset-password
router.post('/reset-password', async (req, res) => {
  const { token, password } = req.body || {};
  if (!token || !password) return res.status(400).json({ error: 'Token and password required.' });
  if (password.length < MIN_PASSWORD_LENGTH) {
    return res.status(400).json({ error: `Password must be at least ${MIN_PASSWORD_LENGTH} characters.` });
  }

  const db = getDb();
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const reset = db.prepare(`
    SELECT * FROM password_resets
    WHERE token_hash = ? AND used_at IS NULL AND expires_at > datetime('now')
  `).get(tokenHash);
  if (!reset) return res.status(400).json({ error: 'Invalid or expired reset link.' });

  const hash = await bcrypt.hash(password, BCRYPT_ROUNDS);
  const tx = db.transaction(() => {
    db.prepare('UPDATE users SET password_hash = ?, token_version = token_version + 1 WHERE id = ?')
      .run(hash, reset.user_id);
    db.prepare("UPDATE password_resets SET used_at = datetime('now') WHERE id = ?").run(reset.id);
    // Invalidate all other pending resets for this user
    db.prepare("UPDATE password_resets SET used_at = datetime('now') WHERE user_id = ? AND used_at IS NULL")
      .run(reset.user_id);
    // Revoke every existing session for this user — password change logs them out everywhere
    db.prepare("UPDATE sessions SET revoked_at = datetime('now') WHERE user_id = ? AND revoked_at IS NULL")
      .run(reset.user_id);
  });
  tx();

  res.json({ message: 'Password updated. You can now log in.' });
});

module.exports = { router, safeUser };
