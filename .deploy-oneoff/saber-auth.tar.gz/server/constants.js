/**
 * Saber Auth — shared constants.
 *
 * KNOWN_SCOPES is the authoritative list of Saber apps this SSO can grant access to.
 * Add a new app here when it's cutover to the shared login (Phase 2+).
 */
'use strict';

const KNOWN_SCOPES = Object.freeze([
  'signalpulse',
  'sentimentpulse',
  'triptracker',
  'genrepulse',
  'gtm',
  'launcher',       // access to the suite landing page /
  'admin',          // can invite/revoke users and grant scopes
]);

const JWT_EXPIRY_DAYS = 30;
const INVITE_EXPIRY_DAYS = 7;
const PW_RESET_EXPIRY_HOURS = 1;
const PW_RESET_RATE_LIMIT_PER_HOUR = 3;
const BCRYPT_ROUNDS = 12;
const MIN_PASSWORD_LENGTH = 10;

module.exports = {
  KNOWN_SCOPES,
  JWT_EXPIRY_DAYS,
  INVITE_EXPIRY_DAYS,
  PW_RESET_EXPIRY_HOURS,
  PW_RESET_RATE_LIMIT_PER_HOUR,
  BCRYPT_ROUNDS,
  MIN_PASSWORD_LENGTH,
};
