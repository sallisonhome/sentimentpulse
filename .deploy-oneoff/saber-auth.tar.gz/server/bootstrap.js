/**
 * On first startup, if the users table is empty AND BOOTSTRAP_ADMIN_EMAIL is set,
 * create the first admin. If BOOTSTRAP_ADMIN_PASSWORD is set, activate immediately.
 * Otherwise, create as `invited` and print an accept URL to the console.
 */
'use strict';

const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { v4: uuid } = require('uuid');
const { getDb } = require('./db/schema');
const { KNOWN_SCOPES, INVITE_EXPIRY_DAYS, BCRYPT_ROUNDS } = require('./constants');

async function bootstrapAdmin() {
  const db = getDb();
  const count = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (count > 0) return;

  const email = process.env.BOOTSTRAP_ADMIN_EMAIL;
  if (!email) {
    console.warn('[saber-auth bootstrap] users table empty and BOOTSTRAP_ADMIN_EMAIL not set. No admin created.');
    return;
  }

  const id = uuid();
  const password = process.env.BOOTSTRAP_ADMIN_PASSWORD;
  const scopesJson = JSON.stringify(KNOWN_SCOPES.filter(s => s !== 'admin')); // grant all app scopes
  if (password) {
    const hash = await bcrypt.hash(password, BCRYPT_ROUNDS);
    db.prepare(`
      INSERT INTO users (id, email, display_name, password_hash, status, scopes, is_admin)
      VALUES (?, ?, ?, ?, 'active', ?, 1)
    `).run(id, email, 'Admin', hash, scopesJson);
    console.log(`[saber-auth bootstrap] Seeded admin ${email} as ACTIVE (password from env).`);
    return;
  }

  // No password provided — create as invited with a printable accept URL.
  db.prepare(`
    INSERT INTO users (id, email, display_name, status, scopes, is_admin)
    VALUES (?, ?, ?, 'invited', ?, 1)
  `).run(id, email, 'Admin', scopesJson);
  const raw = crypto.randomBytes(32).toString('hex');
  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  const expiresAt = new Date(Date.now() + INVITE_EXPIRY_DAYS * 86400 * 1000).toISOString();
  db.prepare(`
    INSERT INTO invites (id, user_id, token_hash, expires_at)
    VALUES (?, ?, ?, ?)
  `).run(uuid(), id, hash, expiresAt);
  const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 5100}`;
  console.log(`
============================================================
[saber-auth bootstrap] Seeded admin ${email} as INVITED.

Accept your invitation and set a password here (valid ${INVITE_EXPIRY_DAYS} days):
  ${baseUrl}/auth/accept-invite.html?token=${raw}
============================================================
`);
}

module.exports = { bootstrapAdmin };
