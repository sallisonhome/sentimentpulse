/**
 * Saber Auth — HTTP entry point.
 */
'use strict';

// Load .env if present (dev convenience; production uses systemd env).
try {
  const fs = require('fs');
  const path = require('path');
  const envPath = path.join(__dirname, '..', '.env');
  if (fs.existsSync(envPath)) {
    for (const line of fs.readFileSync(envPath, 'utf8').split('\n')) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/i);
      if (!m) continue;
      let val = m[2];
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      if (!(m[1] in process.env)) process.env[m[1]] = val;
    }
  }
} catch { /* ignore */ }

const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');

const { getDb } = require('./db/schema');
const { bootstrapAdmin } = require('./bootstrap');
const authRoutes = require('./routes/auth').router;
const adminRoutes = require('./routes/admin');

const app = express();
app.set('trust proxy', 1); // behind nginx
app.use(express.json({ limit: '128kb' }));
app.use(cookieParser());

// Static pages (login, accept-invite, reset-password) served from /public.
app.use('/auth', express.static(path.join(__dirname, '..', 'public'), {
  extensions: ['html'],
  fallthrough: true,
  index: false,
}));

// Health check
app.get('/health', (_req, res) => res.json({ ok: true, service: 'saber-auth', now: new Date().toISOString() }));

// API mount points. Nginx maps /auth/api/* → this service, path preserved as /auth/api/*
app.use('/auth/api', authRoutes);
app.use('/auth/api/admin', adminRoutes);

// Also accept the shorter /api/* form for direct local calls
app.use('/api', authRoutes);
app.use('/api/admin', adminRoutes);

// 404 for unknown /auth API routes (static handler above will 404 unknown pages)
app.use('/auth/api', (_req, res) => res.status(404).json({ error: 'Not found.' }));
app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found.' }));

const PORT = parseInt(process.env.PORT || '5100', 10);

async function start() {
  getDb();               // initialize schema
  await bootstrapAdmin();
  app.listen(PORT, () => {
    console.log(`[saber-auth] listening on :${PORT}`);
    console.log(`[saber-auth] base URL: ${process.env.BASE_URL || `http://localhost:${PORT}`}`);
  });
}

start().catch(err => {
  console.error('[saber-auth] failed to start', err);
  process.exit(1);
});
