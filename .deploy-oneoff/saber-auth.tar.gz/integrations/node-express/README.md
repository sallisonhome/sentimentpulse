# Saber Auth — Node/Express integration

Drop this middleware into any Saber Node app to protect it with the shared SSO.

## Install

```bash
npm install jsonwebtoken
cp saber-auth-middleware.js server/saber-auth-middleware.js
```

## Wire up

```js
// server/index.js (or routes.ts)
const { saberAuth } = require('./saber-auth-middleware');

const auth = saberAuth({
  scope: 'signalpulse',                 // this app's scope name (must be in KNOWN_SCOPES)
  loginUrl: '/auth/login.html',         // where to redirect browser callers
});

// Protect every API route in this app
app.use('/api', auth.requireScope);

// Individual route
app.get('/api/whoami', (req, res) => {
  res.json({
    email: req.saberUser.email,
    scopes: req.saberUser.scopes,
    isAdmin: req.saberUser.isAdmin,
  });
});
```

## Environment

```
SABER_AUTH_JWT_SECRET=<same value as saber-auth's JWT_SECRET>
```

If this is wrong, valid users will get 401s. If this is missing, the middleware throws on boot (fail loud, not silent).

## Behavior

| Caller | Missing/bad token | Wrong scope |
|---|---|---|
| Browser (`Accept: text/html`) | 302 → `/auth/login.html?return=<original>` | 302 → `/auth/login.html?return=<original>` |
| API (JSON caller) | `401 {error: "Authentication required."}` | `403 {error: "Scope '…' required."}` |

## Trade-offs (read before you ship)

The middleware does **local** JWT verification against the shared secret. This means:

- **Very fast** — no network hop per request.
- **Doesn't honor per-session or per-user revocation** until the token naturally expires (30 days) OR you rotate `JWT_SECRET` (nuclear).

Concretely: if you revoke a user in `/auth/admin.html`, they lose access to the auth service and to the launcher immediately, but their existing JWT stays valid inside integrated apps until it expires OR you rotate the secret.

**Recommendation for now:** live with this. If it becomes an issue, we'll add a remote-verify endpoint that each app hits (with 60s cache) to check the session/user revocation state — planned for Phase 5.

## Cutover pattern (safe)

Feature-flag the new auth behind an env var so you can flip back to the legacy password if something goes wrong:

```js
if (process.env.SABER_AUTH_ENABLED === 'true') {
  app.use('/api', auth.requireScope);
} else {
  // legacy password gate
}
```

Run both side-by-side for a week, watch logs, then delete the legacy path.
