/**
 * Saber Auth — drop-in Express middleware for any Saber app.
 *
 * Usage:
 *   const { saberAuth } = require('./saber-auth-middleware');
 *   const auth = saberAuth({ scope: 'signalpulse', loginUrl: '/auth/login.html' });
 *
 *   app.use(auth.requireScope);            // protects every subsequent route
 *   app.get('/api/whoami', (req, res) => res.json(req.saberUser));
 *
 * Config:
 *   scope       — REQUIRED, the app scope this instance enforces (e.g. 'signalpulse').
 *   loginUrl    — URL to redirect unauthenticated HTML requests to (default '/auth/login.html').
 *   jwtSecret   — HS256 secret shared with saber-auth. Read from SABER_AUTH_JWT_SECRET env.
 *   verifyUrl   — Optional. If set, instead of local JWT verify we POST the cookie
 *                 to this URL (e.g. https://.../auth/api/verify) and cache the result
 *                 for 60s. Use this if you don't want to share the JWT secret.
 *
 * Handles both browser (HTML redirect) and API (401 JSON) callers based on Accept header.
 */
'use strict';

const jwt = require('jsonwebtoken');
const COOKIE_NAME = 'saber_session';

function readCookie(req, name) {
  const raw = req.headers.cookie;
  if (!raw) return null;
  for (const part of raw.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return decodeURIComponent(v.join('='));
  }
  return null;
}

function extractToken(req) {
  const auth = req.headers.authorization;
  if (auth && auth.startsWith('Bearer ')) return auth.slice(7);
  return readCookie(req, COOKIE_NAME);
}

function isBrowserRequest(req) {
  const accept = req.headers.accept || '';
  return accept.includes('text/html');
}

function saberAuth({ scope, loginUrl = '/auth/login.html', jwtSecret, verifyUrl } = {}) {
  if (!scope) throw new Error('saberAuth: scope is required');
  const secret = jwtSecret || process.env.SABER_AUTH_JWT_SECRET;
  if (!secret && !verifyUrl) {
    throw new Error('saberAuth: either SABER_AUTH_JWT_SECRET env var or verifyUrl must be set');
  }

  async function loadUser(req) {
    const token = extractToken(req);
    if (!token) return null;
    if (verifyUrl) {
      // Remote verify (not implemented here for now — placeholder for future).
      throw new Error('remote verify not implemented; set SABER_AUTH_JWT_SECRET for local verify');
    }
    try {
      const decoded = jwt.verify(token, secret);
      return {
        userId: decoded.sub,
        email: decoded.email,
        scopes: Array.isArray(decoded.scopes) ? decoded.scopes : [],
        isAdmin: !!decoded.is_admin,
        jti: decoded.jti,
      };
      // NOTE: local verify does NOT check per-session or per-user revocation.
      // For that, either share the sqlite DB read-only or use the remote verifyUrl path.
      // The 30-day JWT expiry + admin's ability to rotate JWT_SECRET (nuclear log-out)
      // give a reasonable baseline until we add remote verify.
    } catch {
      return null;
    }
  }

  function reject(req, res, code, error) {
    if (isBrowserRequest(req)) {
      const back = encodeURIComponent(req.originalUrl || req.url);
      const sep = loginUrl.includes('?') ? '&' : '?';
      return res.redirect(302, `${loginUrl}${sep}return=${back}`);
    }
    return res.status(code).json({ error });
  }

  async function requireAuth(req, res, next) {
    const u = await loadUser(req);
    if (!u) return reject(req, res, 401, 'Authentication required.');
    req.saberUser = u;
    next();
  }

  async function requireScope(req, res, next) {
    const u = await loadUser(req);
    if (!u) return reject(req, res, 401, 'Authentication required.');
    if (!u.scopes.includes(scope) && !u.isAdmin) {
      return reject(req, res, 403, `Scope '${scope}' required.`);
    }
    req.saberUser = u;
    next();
  }

  return { requireAuth, requireScope, extractToken, loadUser };
}

module.exports = { saberAuth };
